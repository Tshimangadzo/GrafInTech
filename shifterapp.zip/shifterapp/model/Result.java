package com.example.a800361.shifterapp.model;

public class Result {

    public String message_id;

    public Result(){

    }

    public String getMessage_id() {
        return message_id;
    }

    public void setMessage_id(String message_id) {
        this.message_id = message_id;
    }
}
